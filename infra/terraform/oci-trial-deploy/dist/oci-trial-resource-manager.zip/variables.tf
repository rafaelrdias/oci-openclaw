variable "region" {
  description = "OCI region used by the provider and by the default OCI Responses endpoint."
  type        = string
  default     = "us-chicago-1"
}

variable "compartment_ocid" {
  description = "Compartment OCID where all resources will be created."
  type        = string
}

variable "prefix" {
  description = "Name prefix for all OCI resources."
  type        = string
  default     = "openclaw-trial"
}

variable "ssh_public_key" {
  description = "Public SSH key authorized for opc. Paste the contents of your .pub file; keep the matching private key outside Terraform."
  type        = string

  validation {
    condition     = can(regex("^(ssh-rsa|ssh-ed25519|ecdsa-sha2-[^ ]+|sk-ssh-ed25519@openssh.com|sk-ecdsa-sha2-nistp256@openssh.com) [A-Za-z0-9+/=]+", trimspace(var.ssh_public_key)))
    error_message = "ssh_public_key must be a valid OpenSSH public key, for example: ssh-ed25519 AAAAC3... openclaw-trial"
  }
}

variable "ssh_allowed_cidr" {
  description = "CIDR allowed to access SSH. Prefer your current public IP /32."
  type        = string
  default     = "0.0.0.0/0"
}

variable "vcn_cidr" {
  description = "CIDR block for the VCN."
  type        = string
  default     = "10.20.0.0/16"
}

variable "subnet_cidr" {
  description = "CIDR block for the public subnet."
  type        = string
  default     = "10.20.10.0/24"
}

variable "availability_domain_index" {
  description = "Index of the availability domain returned by OCI."
  type        = number
  default     = 0
}

variable "instance_shape" {
  description = "OCI compute shape. Adjust for your trial quota."
  type        = string
  default     = "VM.Standard.E5.Flex"
}

variable "instance_ocpus" {
  description = "OCPUs for flexible shapes."
  type        = number
  default     = 2
}

variable "instance_memory_in_gbs" {
  description = "Memory in GB for flexible shapes."
  type        = number
  default     = 16
}

variable "boot_volume_size_gbs" {
  description = "Boot volume size."
  type        = number
  default     = 80
}

variable "oracle_linux_version" {
  description = "Oracle Linux major version used to discover the image."
  type        = string
  default     = "9"
}

variable "image_ocid" {
  description = "Optional custom image OCID. Leave empty to use the latest Oracle Linux image."
  type        = string
  default     = ""
}

variable "gateway_port" {
  description = "OpenClaw Gateway port bound to loopback."
  type        = number
  default     = 18789
}

variable "openclaw_npm_version" {
  description = "OpenClaw npm version to install."
  type        = string
  default     = "latest"
}

variable "oci_responses_region" {
  description = "OCI Responses region exported in the gateway environment."
  type        = string
  default     = "us-chicago-1"
}

variable "oci_responses_project_ocid" {
  description = "Optional OCI Generative AI project OCID exported in the gateway environment. This is not a secret."
  type        = string
  default     = ""
}

variable "openai_base_url" {
  description = "Optional OpenAI-compatible base URL exported in the gateway environment. Leave empty to keep a commented example based on oci_responses_region."
  type        = string
  default     = ""
}

variable "grok_model_id" {
  description = "Grok model ID exposed by the custom plugin."
  type        = string
  default     = "xai.grok-4-1-fast-reasoning"
}

variable "gptoss_model_id" {
  description = "Optional GPT-OSS fallback model ID."
  type        = string
  default     = "custom-inference-generativeai-us-chicago-1-oci-oraclecloud-com/openai.gpt-oss-120b"
}

variable "web_search_provider" {
  description = "OpenClaw managed web_search provider. DuckDuckGo is the default because it does not require OCI Grok native web_search availability."
  type        = string
  default     = "duckduckgo"
}

variable "web_search_max_results" {
  description = "Default result count used by OpenClaw managed web_search."
  type        = number
  default     = 5
}

variable "duckduckgo_region" {
  description = "DuckDuckGo region code used by the bundled OpenClaw DuckDuckGo provider."
  type        = string
  default     = "br-pt"
}

variable "duckduckgo_safe_search" {
  description = "DuckDuckGo safe-search level: strict, moderate, or off."
  type        = string
  default     = "moderate"

  validation {
    condition     = contains(["strict", "moderate", "off"], var.duckduckgo_safe_search)
    error_message = "duckduckgo_safe_search must be strict, moderate, or off."
  }
}

variable "install_nginx" {
  description = "Install and start Nginx for future UI/proxy use."
  type        = bool
  default     = true
}
